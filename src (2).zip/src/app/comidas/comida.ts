export interface Comida {
    id: number,
    nombre: string,
    descripcion: string,
    precio: number
}
