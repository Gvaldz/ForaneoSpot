export interface DecodedToken {
  sub: string;
  role: string;
  exp: number; 
}
