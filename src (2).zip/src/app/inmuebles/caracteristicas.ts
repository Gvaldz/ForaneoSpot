export interface Caracteristicas {
    descripcion: string,
    idservicios: number
}
