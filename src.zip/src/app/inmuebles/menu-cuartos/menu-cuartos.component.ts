import { Component } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-menu-cuartos',
  templateUrl: './menu-cuartos.component.html',
  styleUrl: './menu-cuartos.component.css'
})
export class MenuCuartosComponent {
  constructor(private router: Router) {}


}
