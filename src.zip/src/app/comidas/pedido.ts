export interface Pedido {
}
