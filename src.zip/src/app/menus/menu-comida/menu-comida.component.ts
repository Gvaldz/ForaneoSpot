import { Component } from '@angular/core';

@Component({
  selector: 'app-menu-comida',
  templateUrl: './menu-comida.component.html',
  styleUrl: './menu-comida.component.css'
})
export class MenuComidaComponent {

}
