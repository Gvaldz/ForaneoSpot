export interface MenuIU {
    id: number,
    nombre: string,
    descripcion: string,
    precio: any,

}
